#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/dotacoin.png
ICON_DST=../../src/qt/res/icons/dotacoin.ico
convert ${ICON_SRC} -resize 16x16 dotacoin-16.png
convert ${ICON_SRC} -resize 32x32 dotacoin-32.png
convert ${ICON_SRC} -resize 48x48 dotacoin-48.png
convert dotacoin-16.png dotacoin-32.png dotacoin-48.png ${ICON_DST}

